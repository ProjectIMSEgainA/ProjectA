import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk
from tkinter import*

def findstockindash():

    t = Toplevel()
    t.title("Find Data from stockin Table")
    t.geometry("650x550")
    t.configure(bg="gray15")
    
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=217, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x + 2, y=y + 2)
    
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=220, height=40)
    
    def findstockin():
        db=pymysql.connect(host='localhost',user='root',password='root',database='IMS')
        cur = db.cursor()
        xcb = int(cb.get())
        sql = "select catid, prodid, datein, qty from stockin where supid = %d"%(xcb)
        cur.execute(sql)
        data = cur.fetchone()
        e2.insert(0,str(data[0]))
        e3.insert(0,data[1])
        e4.insert(0,data[2])
        e5.insert(0,data[3])
        db.close()
        
        messagebox.showinfo("Hi there"," stockin data find")
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)        
        
        
    def stockinid():
        db = pymysql.connect(host = 'Localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        sql = "select supid from stockin"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        db.close()
        cb['values'] = lst
        
    
    def btclose():
        t.destroy()
    
    
    
    label_bg = "gray1"  # Label background
    btn_bg = "gray10"  # Button background
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5,width = 59)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color,fieldbackground=btn_bg,  # Entry Background Color
                    insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14,"bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)],foreground=[("readonly", "skyblue")])
    
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    canvas = Canvas(master=t, width=700, height=60, bg="dark slate blue")
    canvas.place(x=0, y=0)
    canvas.create_text(350, 30, text="Find Data from stockin Table", font=("Poppins", 15, "bold"), fill="white")
    
    # Form Fields
    ttk.Label(t, text="stockin ID").place(x=50, y=98)
    cb = ttk.Combobox(t, width=28, state="readonly")
    cb.place(x=400, y=100)
    stockinid()
    
    ttk.Label(t, text="stockin Name").place(x=50, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=400, y=140)
    
    ttk.Label(t, text="Password").place(x=50, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=400, y=180)
    
    ttk.Label(t, text="Phone No").place(x=50, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=400, y=220)
    
    ttk.Label(t, text="Email").place(x=50, y=258)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=400, y=260)   
      
    
    create_button(t, "Find", findstockin, 90, 450)
    create_button(t, "Close", btclose, 340, 450)
    
    t.mainloop()