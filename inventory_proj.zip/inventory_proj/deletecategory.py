import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox

def deletecategorydash():
    t = Toplevel()
    t.title("Delete Data from Category Table")
    t.geometry("600x500")
    t.configure(bg="gray15")
    
    # 🌟 Theme Colors
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    def deletecategory():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'Ims')
        cur = db.cursor()
        xcb = int(e1.get())
        sql = "delete from category where catId = %d"%(xcb)
        cur.execute(sql)
        db.commit()
        db.close()
        messagebox.showinfo("Hi there","Data deleted from table for Category Id: "+str(xcb))
        
    def findcatid():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'Ims')
        cur = db.cursor()
        sql = "select catId from category"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        db.close()
        e1['values'] =lst
        
    def btclose():
        t.destroy()
        
    # 🎯 Tkinter Styling
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 14, "bold"), padding=4, width=43)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # 🎯 Header Canvas
    canva = Canvas(master=t, width=595, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Delete Data from Category", font=("Poppins", 15, "bold"), fill=text_color)
    
    # 🎯 Labels
    ttk.Label(t, text="Category ID", style="TLabel").place(x=50, y=98)
    
    # 🎯 Combobox
    e1 = ttk.Combobox(t, width=28, state="readonly")
    e1.place(x=355, y=100)
    findcatid()
    
    # 🌟 Button Function to Add Border Effect
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=197, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=200, height=40)  # Adjust button size to fit inside the border
    
    # 🎯 Buttons
    create_button(t, "Delete", deletecategory, 70, 350)
    create_button(t, "Close", btclose, 310, 350)
    
    t.mainloop()
