import pymysql
import tkinter
from tkinter import Tk, Canvas
from tkinter import Tk, Canvas, ttk
from tkinter import ttk  # Import ttk for styling
from tkinter import *
from tkinter import messagebox


def showbillingdash():
    # 🌟 Create Tkinter Window
    t1 = Tk()
    t1.geometry("700x600")
    t1.configure(bg="gray15")
    t1.title("Show All Data from Billing Table")
    
    # 🌟 Theme Colors
    label_bg = "gray1"
    text_color = "white"
    border_color = "slate blue"
    
    def showbillingdata():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        sql = "select * from billing"
        cur.execute(sql)
        data = cur.fetchall()
        show = ''
        for i in data:
            show = show +str(i[0])+"\t"
            show = show +str(i[1])+"\t"
            show = show +str(i[2])+"\t"
            show = show +str(i[3])+"\t"
            show = show +str(i[4])+"\t"
            show = show +"\n"
        db.close()
        ta.insert(END,show)
    # 🎯 Tkinter Styling
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 14, "bold"), padding=5)
    style.configure("TText", font=("Poppins", 12), padding=5, background="gray10", foreground="white")
    
    # 🎯 Header Canvas
    canva = Canvas(master=t1, width=696, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(350, 30, text="Show All Data from Billing Table", font=("Poppins", 15, "bold"), fill="white")
    
    # 🎯 Text Area for Data Display
    ta = Text(t1, width=85, height=30, bg="gray10", fg="white", font=("Poppins", 12), bd=0, wrap=NONE)
    ta.place(x=20, y=100)
    
    # 🎯 Show Data
    showbillingdata()
    
    # 🎯 Run the Tkinter Loop
    t1.mainloop()
