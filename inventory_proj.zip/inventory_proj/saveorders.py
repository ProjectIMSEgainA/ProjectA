import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk


def saveorderdash():
    t = tkinter.Toplevel()
    t.title("Insert Data into Orders Table")
    t.geometry("650x550")
    t.configure(bg="gray15")
    
    def create_button(master, text, command, x, y):
        frame = tkinter.Canvas(master, width=127, height=40, bg="slate blue", highlightthickness=0)
        frame.place(x=x + 2, y=y + 2)
    
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=130, height=40)
    
    # Original functions
    def saveorders():
        if len(e1.get()) == 0 or len(e2.get()) == 0 or len(e3.get()) == 0 or len(e4.get()) == 0 or len(e5.get()) == 0:
            messagebox.showerror('Hi', 'No data found')
        elif int(e7.get()) <= 0:
            messagebox.showerror('Hi', 'Quantity should be more than zero')
        else:
            checkorderno()
            db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
            cur = db.cursor()
            xe1 = int(e1.get())
            xe2 = int(e2.get())
            xe3 = int(e3.get())
            xe4 = int(e4.get())
            xe5 = e5.get()
            xe6 = e6.get()
            xe7 = int(e7.get())
            sql = "insert into orders values (%d, %d, %d, %d, '%s', '%s', %d)" % (xe1, xe2, xe3, xe4, xe5, xe6, xe7)
            cur.execute(sql)
            db.commit()
            db.close()
            messagebox.showinfo('Hi there', 'Data inserted in Orders Table')
            updateqty()
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
    
    def catData():
        db = pymysql.connect(host="localhost", user="root", password="root", database="ims")
        cur = db.cursor()
        sql = "select catId from category"
        cur.execute(sql)
        data = cur.fetchall()
        lst = [i[0] for i in data]
        db.close()
        e3['values'] = lst
    
    def prodData():
        db = pymysql.connect(host='localhost', user='root', password='root', database='ims')
        cur = db.cursor()
        sql = "select prodId from products"
        cur.execute(sql)
        data = cur.fetchall()
        lst = [i[0] for i in data]
        db.close()
        e4['values'] = lst
    
    def prodName():
        db = pymysql.connect(host='localhost', user='root', password='root', database='ims')
        cur = db.cursor()
        sql = "select prodName from products"
        cur.execute(sql)
        data = cur.fetchall()
        lst = [i[0] for i in data]
        db.close()
        e5['values'] = lst
    
    def custData():
        db = pymysql.connect(host='localhost', user='root', password='root', database='ims')
        cur = db.cursor()
        sql = "select custId from customers"
        cur.execute(sql)
        data = cur.fetchall()
        lst = [i[0] for i in data]
        db.close()
        e2['values'] = lst
    
    def checkorderno():
        db = pymysql.connect(host='localhost', user='root', password='root', database='ims')
        cur = db.cursor()
        xe1 = int(e1.get())
        sql = "select count(*) from orders where orderNo = %d" % (xe1)
        cur.execute(sql)
        data = cur.fetchone()
        if data[0] == 0:
            messagebox.showinfo("Hi", "Order No is available to use. Go ahead!")
        else:
            messagebox.showinfo("Hi", "This order No is already in use. Enter a new order No.")
            t.destroy()
        db.close()
    
    def updateqty():
        db = pymysql.connect(host='localhost', user='root', password='root', database='ims')
        cur = db.cursor()
        xe4 = int(e4.get())
        xe7 = int(e7.get())
        sql = "update products set qty = qty - %d where prodId = %d" % (xe7, xe4)
        cur.execute(sql)
        db.commit()
        db.close()
        messagebox.showinfo("Hi", "Quantity updated")
    
    def btclose():
        t.destroy()
    
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    # Tkinter Style
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=59)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly",btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # Header Canvas
    canvas = tkinter.Canvas(master=t, width=646, height=60, bg="dark slate blue",highlightbackground="khaki1", highlightthickness=2)
    canvas.place(x=0, y=0)
    canvas.create_text(350, 30, text="Insert Data into Orders Table", font=("Poppins", 15, "bold"), fill="white")
    
    # Form Fields
    ttk.Label(t, text="Order No").place(x=50, y=98)
    e1 = ttk.Entry(t, width=30)
    e1.place(x=400, y=100)
    
    ttk.Label(t, text="Customer ID").place(x=50, y=138)
    e2 = ttk.Combobox(t, width=28, state="readonly")
    e2.place(x=400, y=140)
    custData()
    
    ttk.Label(t, text="Category ID").place(x=50, y=178)
    e3 = ttk.Combobox(t, width=28,state="readonly")
    e3.place(x=400, y=180)
    catData()
    
    ttk.Label(t, text="Product ID").place(x=50, y=218)
    e4 = ttk.Combobox(t, width=28,state="readonly")
    e4.place(x=400, y=220)
    prodData()
    
    ttk.Label(t, text="Product Name").place(x=50, y=258)
    e5 = ttk.Combobox(t, width=28,state="readonly")
    e5.place(x=400, y=260)
    prodName()
    
    ttk.Label(t, text="Date Of Order").place(x=50, y=298)
    e6 = ttk.Entry(t, width=30)
    e6.place(x=400, y=300)
    
    ttk.Label(t, text="Quantity").place(x=50, y=338)
    e7 = ttk.Entry(t, width=30)
    e7.place(x=400, y=340)
    
    # Buttons
    create_button(t, "Save", saveorders, 80, 450)
    create_button(t, "Close", btclose, 250, 450)
    create_button(t, "Check", checkorderno, 430, 450)
    
    t.mainloop()
