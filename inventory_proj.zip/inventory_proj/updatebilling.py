import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter import Canvas

def updatebillingdash():
    t = Toplevel()
    t.title("Update Data from Billing Table")
    t.geometry("600x500")
    t.configure(bg="gray15")
    
    # 🌟 Theme Colors
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    # 🎯 Fetch Data for Selected Bill No
    def findbilling():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        xcb = int(cb.get())
        sql = "SELECT orderNo, custId, dispatchdate, amount FROM billing WHERE billNo = %d" % (xcb)
        cur.execute(sql)
        data = cur.fetchone()
        e2.insert(0, data[0])
        e3.insert(0, data[1])
        e4.insert(0, str(data[2]))
        e5.insert(0, data[3])
        db.close()
        messagebox.showinfo("Hi there", "Data found for Bill No: " + str(xcb))
    
    # 🎯 Update Data in Database
    def updatebilling():
        if len(cb.get()) == 0 or len(e2.get()) == 0 or len(e3.get()) == 0 or len(e4.get()) == 0 or len(e5.get()) == 0:
            messagebox.showerror('Error', 'All fields are required')
        elif int(e5.get()) <= 0:
            messagebox.showerror("Error", "Amount should be greater than zero")
        else:
            db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
            cur = db.cursor()
            xcb = int(cb.get())
            xe2 = int(e2.get())
            xe3 = int(e3.get())
            xe4 = e4.get()
            xe5 = int(e5.get())
            sql = "UPDATE billing SET orderNo = %d, custId = %d, dispatchdate = '%s', amount = %d WHERE billNo = %d" % (xe2, xe3, xe4, xe5, xcb)
            cur.execute(sql)
            db.commit()
            db.close()
            messagebox.showinfo('Success', 'Data updated for Bill No: ' + str(xcb))
            clear_fields()
            e2.delete(0, END)
            e3.delete(0, END)
            e4.delete(0, END)
            e5.delete(0, END)
    # 🎯 Fetch All Bill Numbers
    def findbillno():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        cur.execute("SELECT billNo FROM billing")
        data = cur.fetchall()
        lst = [str(i[0]) for i in data]
        db.close()
        cb['values'] = lst
    
    # 🎯 Clear Input Fields
    def clear_fields():
        cb.set('')
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e5.delete(0, END)
    
    # 🎯 Close Window
    def btclose():
        t.destroy()
    
    # 🌟 Tkinter Style Configuration
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # 🌟 Header Canvas
    canva = Canvas(t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Update Data from Billing Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # 🌟 Labels and Comboboxes
    ttk.Label(t, text="Bill No", style="TLabel").place(x=55, y=98)
    cb = ttk.Combobox(t, width=28, state="readonly")
    cb.place(x=355, y=100)
    findbillno()
    
    ttk.Label(t, text="Order No", style="TLabel").place(x=55, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=355, y=140)
    
    ttk.Label(t, text="Customer ID", style="TLabel").place(x=55, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=355, y=180)
    
    ttk.Label(t, text="Dispatch Date", style="TLabel").place(x=55, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=355, y=220)
    
    ttk.Label(t, text="Amount", style="TLabel").place(x=55, y=258)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=355, y=260)
    
    # 🌟 Button Function to Add Border Effect
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=147, height=35, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=150, height=35)
    
    # 🌟 Buttons
    create_button(t, "Find", findbilling, 60, 350)
    create_button(t, "Update", updatebilling, 230, 350)
    create_button(t, "Close", btclose, 400, 350)
    
    t.mainloop()
