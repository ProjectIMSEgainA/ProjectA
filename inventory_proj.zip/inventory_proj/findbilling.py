import pymysql
import tkinter
from tkinter import Tk, Canvas
from tkinter import Tk, Canvas, ttk
from tkinter import ttk  # Import ttk for styling
from tkinter import *
from tkinter import messagebox


def findbillingdash():    
    
    t = Toplevel()
    t.title("Find Data from Billing Table")
    t.geometry("700x500")
    t.configure(bg="gray15")
    
    label_bg = "gray1"  # Label background
    btn_bg = "gray10"  # Button background
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    def findbilling():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        xcb = int(cb.get())
        sql = "select orderNo, custId, dispatchdate, amount from billing where billNo = %d"%(xcb)
        cur.execute(sql)
        data = cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        e4.insert(0,str(data[2]))
        e5.insert(0,data[3])
        db.close()
        messagebox.showinfo("Hi there","Data found for bill no: "+str(xcb))
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e5.delete(0, END)
        
    def billno():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        sql = "select billNo from billing"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        #lst = [str(i[0]) for i in data]
        db.close()
        cb['values']=lst
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=197, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=200, height=40)  # Adjust button size to fit inside the border
        
    def btclose():
        t.destroy()    
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5,width = 53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color,fieldbackground=btn_bg,  # Entry Background Color
                    insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14,"bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)],foreground=[("readonly", "skyblue")])
    
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # 🖌️ Canvas for Header
    canva = Canvas(t, width=696, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Find Data from Billing Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Labels and Inputs
    ttk.Label(t, text="Bill No", style="TLabel").place(x=55, y=98)
    cb = ttk.Combobox(t, width=28, state="readonly")
    cb.place(x=355, y=100)
    billno()
    ttk.Label(t, text="Order No", style="TLabel").place(x=55, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=355, y=140)
    
    ttk.Label(t, text="Customer ID", style="TLabel").place(x=55, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=355, y=180)
    
    ttk.Label(t, text="Dispatch Date", style="TLabel").place(x=55, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=355, y=220)
    
    ttk.Label(t, text="Amount", style="TLabel").place(x=55, y=258)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=355, y=260)
    
    
    # Buttons
    create_button(t, "Find",findbilling , 90, 350)
    create_button(t, "Close", btclose, 320, 350)
    t.mainloop()