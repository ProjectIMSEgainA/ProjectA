from tkinter import Tk, Canvas
from tkinter import ttk  # Import ttk for styling
from saveproducts import *
from deleteproducts import *
from findproducts import *
from updateproducts import *
from showproductsdata import *
from navigateproducts import *

def prodDash():

    t = Toplevel()
    t.title("Products Dashboard")
    t.geometry("500x500")
    
    def close():
        t.destroy()
    
    # 🎨 Dark Theme Colors
    bg_color = "gray9"
    canva_bg = "DarkSlateBlue"
    btn_bg = "DarkSlateBlue"  # Button background
    btn_fg = "White"
    hover_bg = "SkyBlue"  # Hover effect
    border_color = "khaki1"  # Button border color
    border_width = 3
    text_color = "white"
    
    # 🖌️ Set the background for the entire window
    t.configure(bg=bg_color)
    
    # 🖌️ Canvas for Header
    canva = Canvas(master=t, width=495, height=60, bg=canva_bg, highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(260, 30, text="Products Dashboard", font=("Arial", 15, "bold"), fill=text_color)
    
    # 🌟 Fix Button Styling with Borders and Colors
    style = ttk.Style()
    style.theme_use("clam")  # Ensure full style control
    
    style.configure("TButton",
                    font=('Arial', 13, 'bold'),
                    foreground=btn_fg,
                    background=btn_bg,
                    relief="solid",  # Gives a border effect
                    borderwidth=border_width,
                    padding=5)
    
    style.map("TButton",
              background=[["active", hover_bg]],  # Changes color on hover
              foreground=[["active", "Black"]])  # Text color when hovered
    
    # Function to create a button with border effect
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=197, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x+2 - border_width, y=y+2 - border_width)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=200, height=40)  # Adjust button size to fit inside the border
    
    # 🌟 Buttons with Borders
    create_button(t, 'Insert', saveproductsdash, 160, 100)
    create_button(t, 'Delete', deleteproductsdash, 160, 150)
    create_button(t, 'Find', findproductsdash, 160, 200)
    create_button(t, 'Update', updateproductsdash, 160, 250)
    create_button(t, 'Show_Data', showproductsdash, 160, 300)
    create_button(t, 'Navigator', navigateproductsdash, 160, 350)
    create_button(t, 'X', close, 160, 400)
    
    t.mainloop()
