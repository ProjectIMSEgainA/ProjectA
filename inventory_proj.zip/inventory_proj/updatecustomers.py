import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk
from tkinter import *

def updatecustomerdash():
    t = tkinter.Toplevel()
    t.title("Update Customer")
    t.geometry("600x550")
    t.configure(bg="gray15")
    
    
    def customersfind():
        db=pymysql.connect(host = "Localhost",user = "root",password = "root", database = "Ims")
        cur=db.cursor()
        xcb=int(e1.get())
        sql="select custname,address,phoneNo,city,email from customers where custid = %d"%(xcb)
        cur.execute(sql)
        db.commit()
        data = cur.fetchone()    
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        e4.insert(0,data[2])
        e5.insert(0,data[3])
        e6.insert(0,data[4])
        messagebox.showinfo("Hi","Data Found From Customers Table:"+str(xcb))
        db.close()    
        
    def customersupdate():
        db=pymysql.connect(host = "Localhost",user = "root",password = "root", database = "Ims")
        cur=db.cursor()
        xcb=int(e1.get())
        xb=e2.get()
        xc=e3.get()
        xd=e4.get()
        xf=e5.get()
        xg=e6.get()
        sql = "update customers set custName = '%s', address = '%s', phoneNo = '%s', city = '%s',email = '%s' where custid = %d"%(xb,xc,xd,xf,xg,xcb)
        cur.execute(sql)
        db.commit()
        db.close()
        messagebox.showinfo("Hi there ","Data Update in Customers Table:"+str(xcb))    
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)
        e6.delete(0,100)
    def nw():        
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)
        e6.delete(0,100)
    def showcustid():
        db=pymysql.connect(host = "Localhost",user = "root",password = "root", database = "Ims")
        cur=db.cursor()
        sql = "select custid from customers"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        db.close()
        e1["values"] = lst
            
    def btclose():
        t.destroy()
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=147, height=35, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=150, height=35)
    
    label_bg = "gray1"
    text_color = "white"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    canva = Canvas(t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Update Data from Customers Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    ttk.Label(t, text="Customer ID").place(x=50, y=98)
    e1 = ttk.Combobox(t, width=28, state="readonly")
    e1.place(x=350, y=100)
    showcustid()
    
    ttk.Label(t, text="Customer Name").place(x=50, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=350, y=140)
    
    ttk.Label(t, text="Address").place(x=50, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=350, y=180)
    
    ttk.Label(t, text="Phone No").place(x=50, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=350, y=220)
    
    ttk.Label(t, text="City").place(x=50, y=258)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=350, y=260)
    
    ttk.Label(t, text="Email").place(x=50, y=298)
    e6 = ttk.Entry(t, width=30)
    e6.place(x=350, y=300)
    
    
    
    create_button(t, "Find", customersfind, 50, 400)
    create_button(t, "Update", customersupdate, 220, 400)
    create_button(t, "Close", btclose, 390, 400)
    
    
    
    t.mainloop()
