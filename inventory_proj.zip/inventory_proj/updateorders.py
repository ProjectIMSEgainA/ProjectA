import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk
from tkinter import *

def updateorderdash():
    t = tkinter.Toplevel()
    t.title("Update Orders")
    t.geometry("600x550")
    t.configure(bg="gray15")
    
    
    def findorders():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        xcb = int(cb.get())
        sql = "select custId, catId, prodId, prodName, dateoforder, qty from orders where orderNo = %d" % (xcb)
        cur.execute(sql)
        data = cur.fetchone()
        e2.insert(0, data[0])
        e3.insert(0, data[1])
        e4.insert(0, data[2])
        e5.insert(0, data[3])
        e6.insert(0, data[4])
        e7.insert(0, data[5])
        db.close()
        messagebox.showinfo("Success", "Data found for Order No: " + str(xcb))
        
    
    def updateorders():
        if int(e7.get()) <= 0:
            messagebox.showerror('Error', 'Quantity should be more than zero')
        else:
            db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
            cur = db.cursor()
            xcb = int(cb.get())
            xe2 = int(e2.get())
            xe3 = int(e3.get())
            xe4 = int(e4.get())
            xe5 = e5.get()
            xe6 = e6.get()
            xe7 = int(e7.get())
            sql = "update orders set custId = %d, catId = %d, prodId = %d, prodName = '%s', dateoforder = '%s', qty = %d where orderNo = %d" % (xe2, xe3, xe4, xe5, xe6, xe7, xcb)
            cur.execute(sql)
            db.commit()
            db.close()
            messagebox.showinfo("Success", "Data updated for Order No: " + str(xcb))
            clear_fields()
            e2.delete(0, END)
            e3.delete(0, END)
            e4.delete(0, END)
            e5.delete(0, END)
            e6.delete(0, END)
            e7.delete(0, END)
    
    def showorderno():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        sql = "select orderNo from orders"
        cur.execute(sql)
        data = cur.fetchall()
        cb['values'] = [i[0] for i in data]
        db.close()
    
    def clear_fields():
        cb.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e5.delete(0, END)
        e6.delete(0, END)
        e7.delete(0, END)
    
    def btclose():
        t.destroy()
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=147, height=35, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=150, height=35)
    
    label_bg = "gray1"
    text_color = "white"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    canva = Canvas(t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Update Data from Billing Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    ttk.Label(t, text='Order No', style="TLabel").place(x=50, y=98)
    cb = ttk.Combobox(t, width=17, state ="readonly")
    cb.place(x=410, y=100)
    
    ttk.Label(t, text='Customer Id', style="TLabel").place(x=50, y=138)
    e2 = ttk.Entry(t, width=20)
    e2.place(x=410, y=140)
    
    ttk.Label(t, text='Category Id', style="TLabel").place(x=50, y=178)
    e3 = ttk.Entry(t, width=20)
    e3.place(x=410, y=180)
    
    ttk.Label(t, text='Product Id', style="TLabel").place(x=50, y=218)
    e4 = ttk.Entry(t, width=20)
    e4.place(x=410, y=220)
    
    ttk.Label(t, text='Product Name', style="TLabel").place(x=50, y=258)
    e5 = ttk.Entry(t, width=20)
    e5.place(x=410, y=260)
    
    ttk.Label(t, text='Date Of Order', style="TLabel").place(x=50, y=298)
    e6 = ttk.Entry(t, width=20)
    e6.place(x=410, y=300)
    
    ttk.Label(t, text='Quantity', style="TLabel").place(x=50, y=338)
    e7 = ttk.Entry(t, width=20)
    e7.place(x=410, y=340)
    
    
    
    create_button(t, "Find", findorders, 50, 400)
    create_button(t, "Update", updateorders, 220, 400)
    create_button(t, "Close", btclose, 390, 400)
    
    showorderno()
    
    t.mainloop()
