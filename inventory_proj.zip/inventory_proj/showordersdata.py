import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk
from tkinter import *

def showorderdash():
    t = tkinter.Toplevel()
    t.title("Show All Orders Data")
    t.geometry("650x600")
    t.configure(bg="gray15")
    
    label_bg = "gray1"  # Label background
    text_color = "white"
    border_color = "slate blue"
    
    def showordersdata():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        sql = "select * from orders"
        cur.execute(sql)
        data = cur.fetchall()
        res = ''
        for i in data:
            res = res + str(i[0]) + "\t"
            res = res + str(i[1]) + "\t"
            res = res + str(i[2]) + "\t"
            res = res + str(i[3]) + "\t"
            res = res + str(i[4]) + "\t"
            res = res + str(i[5]) + "\t"
            res = res + str(i[6]) + "\t"
            res = res + "\n"
        db.close()
        ta.insert(END, res)
    
    # Canvas Header
    canva = Canvas(t, width=646, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Show All Data from Orders Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Text Area
    ta = Text(t, width=75, height=30, bg=label_bg, fg=text_color, font=("Poppins", 12), insertbackground="white", borderwidth=2, relief="solid")
    ta.place(x=20, y=100)
    
    # Fetch Data
    showordersdata()
    
    t.mainloop()