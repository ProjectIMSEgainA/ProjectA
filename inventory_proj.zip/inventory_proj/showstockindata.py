import tkinter
import pymysql
from tkinter import messagebox
from tkinter import ttk
from tkinter import *

def showstockindash():
    t = tkinter.Toplevel()
    t.title("Show All stockin Data")
    t.geometry("650x600")
    t.configure(bg="gray15")
    
    label_bg = "gray1"  # Label background
    text_color = "white"
    border_color = "slate blue"
    
    def showstockindata():
        db=pymysql.connect(host = "Localhost", user = "root", password = "root",database = "Ims")
        cur=db.cursor()
        sql = "select * from stockin"
        cur.execute(sql)
        data = cur.fetchall()
        show = ''
        for i in data:
            show = show +str(i[0])+"\t"
            show = show +str(i[1])+"\t"
            show = show +str(i[2])+"\t"
            show = show +str(i[3])+"\t"
            show = show +str(i[4])+"\t"
            #show = show +str(i[5])+"\t"
            show = show + "\n"
        db.close()
        ta.insert(END,show)
    
    # Canvas Header
    canva = Canvas(t, width=646, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Show All Data from Stockin Table", font=("Poppins", 15, "bold"), fill=text_color)
        
    # Text Area
    ta = Text(t, width=75, height=30, bg=label_bg, fg=text_color, font=("Poppins", 12), insertbackground="white", borderwidth=2, relief="solid")
    ta.place(x=20, y=100)
    
    # Fetch Data
    showstockindata()    
    t.mainloop()