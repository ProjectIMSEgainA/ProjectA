import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


rt=[]
def saveproductsdash():
    t = Toplevel()
    t.title("Save Data to Products Table")
    t.geometry("600x500")
    t.configure(bg="gray15")    
        
        
        # Function to Save Billing Data
       
    
    def fillcategory():
        db=pymysql.connect(host='localhost',user='root',password='root',database='IMS')
        cur = db.cursor()
        sql="select catid from category" 
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            rt.append(res[0])
        e2['values']=rt
        db.close()
    def saveproducts():
        if len(e1.get())==0 or len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
            messagebox.showerror('Hi','Pls fill all data')
        else:
            checkproducts()
            db=pymysql.connect(host='localhost',user='root',password='root',database='IMS')
            cur = db.cursor()
            xe1 = int(e1.get())
            xe2 = int(e2.get())
            xe3 = e3.get()
            xe4 = int(e4.get())
            xe5 = int(e5.get())
            sql = "insert into products values (%d,%d, '%s', %d, %d)"%(xe1, xe2, xe3, xe4, xe5)
            cur.execute(sql)
            db.commit()
            db.close()
            messagebox.showinfo("Hi there","Product data is saved")
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            clear_fields()
    def checkproducts():
        db=pymysql.connect(host='localhost',user='root',password='root',database='IMS')
        cur = db.cursor()
        xe1 = int(e1.get())
        sql="select count(*) from products where prodid=%d"%(xe1)
        cur.execute(sql)
        data=cur.fetchone()
        if data[0]==0:
            messagebox.showinfo('Hi','Ok Please go ahead')
        else:
            messagebox.showerror('HI',"please choose other and open screen again")
            t.destroy()
            db.close()
    
    
    def clear_fields():
         e1.delete(0, END)
         e2.set('')
         e3.set('')
         e4.delete(0, END)
         e5.delete(0, END)
         e6.delete(0, END)
     
    def create_button(master, text, command, x, y):
         frame = Canvas(master, width=127, height=40, bg="slate blue", highlightthickness=0)
         frame.place(x=x+2, y=y+2)
         
         btn = ttk.Button(master, text=text, style="TButton", command=command)
         btn.place(x=x, y=y, width=130, height=40)
         
     # Close Window
    def btclose():
         t.destroy()
     
     # Theme Colors
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
     
     # Tkinter Style
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # Header Canvas
    canva = Canvas(master=t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Insert Data into Products Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Labels and Entries
    ttk.Label(t, text='Product Id').place(x=50, y=98)
    e1 = ttk.Entry(t, width=30)
    e1.place(x=350, y=100)
    
    
    ttk.Label(t, text='Category Id').place(x=50, y=138)
    e2 = ttk.Combobox(t, width=28, state="readonly")
    e2.place(x=350, y=140)
    fillcategory()
    
    ttk.Label(t, text='Product Name').place(x=50, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=350, y=180)
    
    ttk.Label(t, text='Price').place(x=50, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=350, y=220)
    
    ttk.Label(t, text='Quantity').place(x=50, y=258)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=350, y=260)   
    
    # Buttons
    create_button(t, "Save", saveproducts, 55, 350)
    create_button(t, "Close", btclose, 220, 350)
    create_button(t, "Check", checkproducts, 390, 350)
     
    t.mainloop()


