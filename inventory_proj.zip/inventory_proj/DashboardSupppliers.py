from tkinter import Tk, Canvas
from tkinter import ttk  # Import ttk for styling
from savesuppliers import *
from deletesuppliers import *
from findsuppliers import *
from updatesuppliers import *
from showsuppliers import *
from navigatesuppliers import *

def supDash():

    t = Toplevel()
    t.title("Suppliers Dashboard")
    t.geometry("500x500")
    
    def close():
        t.destroy()
    
    # 🎨 Dark Theme Colors
    bg_color = "gray9"
    canva_bg = "DarkSlateBlue"
    btn_bg = "DarkSlateBlue"  # Button background
    btn_fg = "White"
    hover_bg = "SkyBlue"  # Hover effect
    border_color = "khaki1"  # Button border color
    border_width = 3
    text_color = "white"
    
    # 🖌️ Set the background for the entire window
    t.configure(bg=bg_color)
    
    # 🖌️ Canvas for Header
    canva = Canvas(master=t, width=495, height=60, bg=canva_bg, highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(260, 30, text="Suppliers Dashboard", font=("Arial", 15, "bold"), fill=text_color)
    
    # 🌟 Fix Button Styling with Borders and Colors
    style = ttk.Style()
    style.theme_use("clam")  # Ensure full style control
    
    style.configure("TButton",
                    font=('Arial', 13, 'bold'),
                    foreground=btn_fg,
                    background=btn_bg,
                    relief="solid",  # Gives a border effect
                    borderwidth=border_width,
                    padding=5)
    
    style.map("TButton",
              background=[["active", hover_bg]],  # Changes color on hover
              foreground=[["active", "Black"]])  # Text color when hovered
    
    # Function to create a button with border effect
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=197, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x+2 - border_width, y=y+2 - border_width)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=200, height=40)  # Adjust button size to fit inside the border
    
    # 🌟 Buttons with Borders
    create_button(t, 'Insert', savesuppliersdash, 160, 100)
    create_button(t, 'Delete', deletesuppliersdash, 160, 150)
    create_button(t, 'Find', findsuppliersdash, 160, 200)
    create_button(t, 'Update', updatesuppliersdash, 160, 250)
    create_button(t, 'Show_Data', showsuppliersdash, 160, 300)
    create_button(t, 'Navigator', navigatesuppliersdash, 160, 350)
    create_button(t, 'X', close, 160, 400)
    
    t.mainloop()
