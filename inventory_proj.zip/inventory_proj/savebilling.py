import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def savebillingdash():
    t = Toplevel()
    t.title("Save Data to Billing Table")
    t.geometry("600x500")
    t.configure(bg="gray15")    
    to_email = ""
    
    # Function to Save Billing Data
    def savebilling():
       if len(e1.get())==0 or len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
           messagebox.showerror('Hi','No data found')
       else:
           checkbillno()
           db=pymysql.connect(host='localhost',user='root',password='root',database='IMS')
           cur = db.cursor()
           xe1 = int(e1.get())
           xe2 = int(e2.get())
           xe3 = int(e3.get())
           xe4 = e4.get()
           xe5 = int(e5.get())
           sql = "insert into billing values (%d,%d, %d, '%s', %d)"%(xe1, xe2, xe3, xe4, xe5)
           cur.execute(sql)
           db.commit()
           db.close()
           messagebox.showinfo("Hi there","Billing data is saved")
           findemail()
           e1.delete(0,100)
           e2.delete(0,100)
           e3.delete(0,100)
           e4.delete(0,100)
           e5.delete(0,100)
   
    def checkbillno():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        xe1 = int(e1.get())
        sql = "select count(*) from billing where billNo = %d"%(xe1)
        cur.execute(sql)
        data = cur.fetchone()
        if data[0]==0:
            messagebox.showinfo("hi","Available to use this Bill No")
        else:
            messagebox.showinfo("hi","This billNo already exist please select new billNo")
            t.destroy()
        db.close()
    
    def custData():
        db=pymysql.connect(host='localhost',user='root',password='root',database='Ims')
        cur = db.cursor()
        sql = "select custId from customers"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        db.close()
        e3['values']=lst
    
    def orderNo():
        db=pymysql.connect(host='localhost',user='root',password='root',database='Ims')
        cur = db.cursor()
        sql = "select orderNo from orders"
        cur.execute(sql)
        data = cur.fetchall()
        lst = []
        for i in data:
            lst.append(i[0])
        db.close()
        e2['values']=lst
        
    def findemail():
        db=pymysql.connect(host='localhost',user='root',password='root',database='Ims')
        cur = db.cursor()
        xe3 = int(e3.get())
        sql = "select email from customers where custId = %d"%(xe3)
        cur.execute(sql)
        data = cur.fetchone()
        global to_email
        to_email = data[0]
        sendmail()
        
    def sendmail():
        global to_email
        from_address = "khanshariq.2895@gmail.com"
        to_address = to_email
        
        
        # Create message container - the correct MIME type is multipart/alternative.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Bill"
        msg['From'] = from_address
        msg['To'] = to_address
        
        # Create the message (HTML).
        html = "Your total bill is <br>"+str(e5.get())+"<br> and the date of Dispatch of your order is "+e4.get()
        
        
        # Record the MIME type - text/html.
        part1 = MIMEText(html, 'html')
        messagebox.showinfo('Hi there', 'Mail Sent')
    
    
        
        # Attach parts into message container
        msg.attach(part1)
        
        # Credentials
        username = 'khanshariq.2895@gmail.com'  
        password = 'vjjoplvixduasozh'
        
        # Sending the email
        ## note - this smtp config worked for me, I found it googling around, you may have to tweak the # (587) to get yours to work
        server = smtplib.SMTP('smtp.gmail.com', 587) 
        server.ehlo()
        server.starttls()
        server.login(username,password)  
        server.sendmail(from_address, to_address, msg.as_string())  
        server.quit()
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=127, height=40, bg="slate blue", highlightthickness=0)
        frame.place(x=x+2, y=y+2)
    
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=130, height=40)
     
     # Close Window
    def btclose():
        t.destroy()
        
    # Theme Colors
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    # Tkinter Style
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=52)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # Header Canvas
    canva = Canvas(master=t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(350, 30, text="Insert Data into Billing Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Form Fields
    ttk.Label(t, text="Bill No").place(x=50, y=100)
    e1 = ttk.Entry(t, width=30)
    e1.place(x=350, y=100)
    
    ttk.Label(t, text="Order No").place(x=50, y=140)
    e2 = ttk.Combobox(t, width=28, state="readonly")
    e2.place(x=350, y=140)
    orderNo()
    
    ttk.Label(t, text="Customer ID").place(x=50, y=180)
    e3 = ttk.Combobox(t, width=28, state="readonly")
    e3.place(x=350, y=180)
    custData()
    
    ttk.Label(t, text="Dispatch Date").place(x=50, y=220)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=350, y=220)
    
    ttk.Label(t, text="Amount").place(x=50, y=260)
    e5 = ttk.Entry(t, width=30)
    e5.place(x=350, y=260)    
    
    # Buttons
    create_button(t, "Save", savebilling, 55, 350)
    create_button(t, "Close", btclose, 220, 350)
    create_button(t, "Check", checkbillno, 390, 350)
    
    t.mainloop()


