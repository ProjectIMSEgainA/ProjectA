import tkinter
from tkinter import *
import pymysql
from tkinter import messagebox
from tkinter import ttk

def deleteorderdash():
    
    t = tkinter.Toplevel()
    t.title("Delete Data from Orders Table")
    t.geometry("600x500")
    t.configure(bg="gray15")

    def create_button(master, text, command, x, y):
        frame = tkinter.Canvas(master, width=217, height=40, bg="slate blue", highlightthickness=0)
        frame.place(x=x + 2, y=y + 2)

        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=220, height=40)

    def deleteorders():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        xcb = int(cb.get())
        sql = "delete from orders where orderNo = %d" % xcb
        cur.execute(sql)
        db.commit()
        db.close()
        messagebox.showinfo("Hi there", "Data deleted from table for orderNo: " + str(xcb))

    def ordersno():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        sql = "select orderNo from orders"
        cur.execute(sql)
        data = cur.fetchall()
        lst = [i[0] for i in data]
        db.close()
        cb['values'] = lst

    def btclose():
        t.destroy()

    # Tkinter Style
    label_bg = "gray1"  # Label background
    btn_bg = "gray10"  # Button background
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5,width = 52)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color,fieldbackground=btn_bg,  # Entry Background Color
                    insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14,"bold"), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)],foreground=[("readonly", "skyblue")])

    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])

    # Header Canvas
    canvas = tkinter.Canvas(master=t, width=600, height=60, bg="dark slate blue")
    canvas.place(x=0, y=0)
    canvas.create_text(300, 30, text="Delete Data from Orders Table", font=("Poppins", 15, "bold"), fill="white")

    # Dropdown
    ttk.Label(t, text="Order No").place(x=55, y=118)
    cb = ttk.Combobox(t, width=28, state="readonly")
    cb.place(x=340, y=120)
    ordersno()

    # Buttons
    create_button(t, "Delete", deleteorders, 70, 400)
    create_button(t, "Close", btclose, 300, 400)

    t.mainloop()