import tkinter
import pymysql
from tkinter import Tk, Canvas, ttk
from tkinter import *
from tkinter import messagebox

xa = []
xb = []
xc = []
xd = []
xe = []
xf = []
xg = []

i = 0

def navigatesuppliersdash():
    t = Toplevel()
    t.geometry('650x550')
    t.configure(bg="gray15")
    
    label_bg = "gray1"  # Label background
    btn_bg = "gray10"  # Button background
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    def filldata():
        db = pymysql.connect(host='localhost', user='root', password='root', database='IMS')
        cur = db.cursor()
        sql = "select * from suppliers"
        cur.execute(sql)
        data = cur.fetchall()
        for res in data:
            xa.append(res[0])
            xb.append(res[1])
            xc.append(res[2])
            xd.append(res[3])
            #xe.append(res[4])
            #xf.append(res[5])
            
        db.close()
    
    def update_fields():
        e1.delete(0, 'end')
        e2.delete(0, 'end')
        e3.delete(0, 'end')
        e4.delete(0, 'end')
        #e5.delete(0, 'end')
        #e6.delete(0, 'end')
        
    
        e1.insert(0, xa[i])
        e2.insert(0, xb[i])
        e3.insert(0, xc[i])
        e4.insert(0, xd[i])
        #e5.insert(0, xe[i])
        #e6.insert(0, xf[i])
        
    
    def first():
        global i
        i = 0
        update_fields()
    
    def nexta():
        global i
        if i < len(xa) - 1:
            i += 1
            update_fields()
    
    def previous():
        global i
        if i > 0:
            i -= 1
            update_fields()
    
    def last():
        global i
        i = len(xa) - 1
        update_fields()
    
    def btclose():
         t.destroy()
    
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=227, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x + 2, y=y + 2)
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=230, height=40)
    
    # Theme Configuration
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=58)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # Canvas Header
    canva = Canvas(t, width=646, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(300, 30, text="Navigate data from suppliers Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Labels and Entries
    ttk.Label(t, text='Supplier id').place(x=50, y=98)
    e1 = ttk.Entry(t, width=30)
    e1.place(x=400, y=100)
    
    
    ttk.Label(t, text='Supplier Name').place(x=50, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=400, y=140)
    
    ttk.Label(t, text='Address').place(x=50, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=400, y=180)
    
    ttk.Label(t, text='Category id').place(x=50, y=218)
    e4 = ttk.Entry(t, width=30)
    e4.place(x=400, y=220)
    
    # Buttons
    create_button(t, "First", first, 80, 400)
    create_button(t, "Next", nexta, 350, 400)
    create_button(t, "Previous", previous, 80, 450)
    create_button(t, "Last", last, 350, 450)
    create_button(t, "Close", btclose, 220, 500)
    
    # Fetch Data
    filldata()
    
    t.mainloop()
    
    
