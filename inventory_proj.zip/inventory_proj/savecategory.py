import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def savecategorydash():
    t = Toplevel()
    t.title("Save Data to Category Table")
    t.geometry("600x500")
    t.configure(bg="gray15")    
    to_email = ""
    
    # Function to Save Billing Data
    def savecategory():
        if len(e1.get())==0 or len(e2.get())==0 or len(e3.get())==0 :
            messagebox.showerror("Hi","No data found")
        else:
            checkcatid()
            db=pymysql.connect(host = "Localhost", user = "root" , password = "root" , database = "Ims")
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()    
            
            sql = "insert into category values(%d,'%s','%s')"%(xa,xb,xc)
            cur.execute(sql)
            db.commit()
            db.close()
            messagebox.showinfo("Hi","Data Saved")
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
    
    
    def checkcatid():
        db = pymysql.connect(host = 'localhost', user = 'root', password = 'root', database = 'IMS')
        cur = db.cursor()
        xe1 = int(e1.get())
        sql = "select count(*) from category where catId = %d"%(xe1)
        cur.execute(sql)
        data = cur.fetchone()
        for i in data:
            if data[0] == 0:
                messagebox.showinfo("Hi","Go ahead")
            else:
                messagebox.showinfo("Hi","This Id already is in record please enter new Id")
                t.destroy()
        db.close()
        
    def create_button(master, text, command, x, y):
        frame = Canvas(master, width=157, height=40, bg=border_color, highlightthickness=0)
        frame.place(x=x+2, y=y+2)
        
        btn = ttk.Button(master, text=text, style="TButton", command=command)
        btn.place(x=x, y=y, width=160, height=40)  # Adjust button size to fit inside the border
        
    # Close Window
    def btclose():
        t.destroy()
        
    # Theme Colors
    label_bg = "gray1"
    btn_bg = "gray10"
    btn_fg = "black"
    hover_bg = "deep sky blue"
    border_color = "slate blue"
    text_color = "white"
    
    # Tkinter Style
    style = ttk.Style()
    style.theme_use("clam")
    
    style.configure("TLabel", background=label_bg, foreground=text_color, font=("Poppins", 12, "bold"), padding=5, width=53)
    style.configure("TEntry", font=("Poppins", 14), padding=5, foreground=text_color, fieldbackground=btn_bg, insertcolor="green")
    style.configure("TCombobox", font=("Poppins", 14), padding=5, background="dark slate blue", borderwidth=2)
    style.map("TCombobox", fieldbackground=[("readonly", btn_bg)], foreground=[("readonly", "skyblue")])
    style.configure("TButton", font=("Poppins", 14, "bold"), padding=5, background="dark slate blue", foreground=btn_fg, borderwidth=2)
    style.map("TButton", background=[("active", hover_bg)], foreground=[("active", text_color)])
    
    # Header Canvas
    canva = Canvas(master=t, width=596, height=60, bg="dark slate blue", highlightbackground="khaki1", highlightthickness=2)
    canva.place(x=0, y=0)
    canva.create_text(350, 30, text="Insert Data into Category Table", font=("Poppins", 15, "bold"), fill=text_color)
    
    # Labels and Entries
    ttk.Label(t, text="Category ID").place(x=50, y=98)
    e1 = ttk.Entry(t, width=30)
    e1.place(x=350, y=100)
    
    
    ttk.Label(t, text="Category Name").place(x=50, y=138)
    e2 = ttk.Entry(t, width=30)
    e2.place(x=350, y=140)
    
    ttk.Label(t, text="Description").place(x=50, y=178)
    e3 = ttk.Entry(t, width=30)
    e3.place(x=350, y=180)
    
       
    
    # Buttons
    create_button(t, "Save", savecategory, 110, 350)
    create_button(t, "Close", btclose, 320, 350)
    create_button(t, "Check", checkcatid, 220, 400)
    
    t.mainloop()


